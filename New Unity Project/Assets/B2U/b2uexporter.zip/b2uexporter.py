# Cogumelo Softworks - B2U
# THIS SCRIPT IS LICENSED UNDER GPL, 


bl_info = {
    "name": "B2U",
    "author": "Cogumelo Softworks",
    "version": (1,31),
    "blender": (2, 79, 0),
    "location": "Render > B2U - Scene Exporter ",
    "description": "Custom from Blender to Unity3D",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Import-Export"
}

import bpy
import random
import math
import mathutils
import os
import time
import shutil
import filecmp
import xml.etree.cElementTree as ET
import nodeitems_utils
import collections
from nodeitems_utils import NodeCategory, NodeItem

# ------------------- Funções de auxilio ---------------------
def to_hex(c):
    if c < 0.0031308:
        srgb = 0.0 if c < 0.0 else c * 12.92
    else:
        srgb = 1.055 * math.pow(c, 1.0 / 2.4) - 0.055

    return hex(max(min(int(srgb * 255 + 0.5), 255), 0))   
    
def to_hex2(varR):
    if (varR > 0.0031308):
        varR = 1.055 * (pow(varR, (1.0 / 2.4))) - 0.055;
    else:
        varR = 12.92 * varR;
    return hex(max(min(int(varR * 255 + 0.5), 255), 0))   
    
def ExportTexture(image,texSaveCache,Texture_Dir,Textures_Local):
    
    finalPath = ""
    
    if (image != None):
        
        path = image.filepath
        f_name = os.path.basename(path)
        
        # If it's a non packed texture
        if image.packed_file == None and image.source == "FILE":
            
            if(os.path.isfile(Texture_Dir + "/" + f_name)):
                if(filecmp.cmp(bpy.path.abspath(path), (Texture_Dir + "/" + f_name)) == False):
                    shutil.copyfile(bpy.path.abspath(path),Texture_Dir + "/" + f_name)
                finalPath = Textures_Local + "/" + f_name

            else:
                pathtemp = os.path.basename(image.filepath.replace("//","/"))
                shutil.copyfile(bpy.path.abspath(path),Texture_Dir + "/" + pathtemp)
                finalPath = Textures_Local + "/" + pathtemp
            
        # if it's packed
        else:
            #Cache Settings
            cacheType = bpy.context.scene.render.image_settings.file_format
            cacheColorMode = bpy.context.scene.render.image_settings.color_mode
            cacheColorDept = bpy.context.scene.render.image_settings.color_depth
            cacheCompression = bpy.context.scene.render.image_settings.compression
            cacheQuality = bpy.context.scene.render.image_settings.quality
            
            formatextension = ""
            #Chance Settings
            if(bpy.context.scene.B2U_Settings.textureFormat == "PNG"):
                bpy.context.scene.render.image_settings.file_format = "PNG"
                bpy.context.scene.render.image_settings.color_mode = "RGBA"
                bpy.context.scene.render.image_settings.color_depth = "16"
                bpy.context.scene.render.image_settings.compression = 100
                formatextension = ".png"
            
            elif(bpy.context.scene.B2U_Settings.textureFormat == "TGA"):
                bpy.context.scene.render.image_settings.file_format = "TARGA"
                bpy.context.scene.render.image_settings.color_mode = "RGBA"
                formatextension = ".tga"
                
            elif(bpy.context.scene.B2U_Settings.textureFormat == "JPEG"):
                bpy.context.scene.render.image_settings.file_format = "JPEG"
                cacheQuality = bpy.context.scene.render.image_settings.quality = 100
                formatextension = ".jpg"
            
            imgSettings = bpy.context.scene.render.image_settings
            filename = os.path.splitext(image.name)[0]                                    
            image.name = filename + formatextension

            # Check if was saved already this time
            if(not (image.name in texSaveCache)):
                image.save_render(Texture_Dir + "/" + image.name)
                texSaveCache.append(image.name)
            
            finalPath = Textures_Local + "/" + image.name
            
            #Restore Settings
            bpy.context.scene.render.image_settings.quality = cacheQuality
            bpy.context.scene.render.image_settings.file_format = cacheType
            bpy.context.scene.render.image_settings.color_mode = cacheColorMode
            bpy.context.scene.render.image_settings.color_depth = cacheColorDept
            bpy.context.scene.render.image_settings.compression = cacheCompression
    
    return finalPath


def GetInputSocketByName(node,name):
    for input in node.inputs:
        if input.name == name:
            return input
    return None

# Pretty Print
def indent(elem, level=0):
  i = "\n" + level*"  "
  if len(elem):
    if not elem.text or not elem.text.strip():
      elem.text = i + "  "
    if not elem.tail or not elem.tail.strip():
      elem.tail = i
    for elem in elem:
      indent(elem, level+1)
    if not elem.tail or not elem.tail.strip():
      elem.tail = i
  else:
    if level and (not elem.tail or not elem.tail.strip()):
      elem.tail = i

# DuplicateObject
def duplicateObject(scene, name, copyobj):
 
    # Create new mesh
    mesh = bpy.data.meshes.new(name)
 
    # Create new object associated with the mesh
    ob_new = bpy.data.objects.new(name, mesh)
 
    # Copy data block from the old object into the new object
    ob_new.data = copyobj.to_mesh(scene,apply_modifiers = True,settings = "PREVIEW")
    ob_new.scale = copyobj.scale
    ob_new.location = copyobj.location
    ob_new.rotation_euler = copyobj.rotation_euler
 
    # Link new object to the given scene and select it
    scene.objects.link(ob_new)
    ob_new.select = True

    return ob_new
    
def GetDirectData(intSocket,type):
    
    value = None
    connected = False
    if(intSocket == None):
        return value
        
    if(len(intSocket.links)>0):
        socket = intSocket.links[0].from_socket
        
        if(type == "COLOR"): #Input with RGB Input Color
        
            rgb = socket.default_value[:] # Comportamento normal
            value = (to_hex(rgb[0])[2:] + to_hex(rgb[1])[2:] + to_hex(rgb[2])[2:]).upper()
            

        if(type == "FLOAT"):
            value = socket.default_value
            
        if(type == "BOOL"):
            value = socket.default_value
            
        if(type == "KEY"):
            value = socket.default_value
            
        if(type == "TEXTURE"):
            
            typeNode = socket.links[0].from_node.type
            if(typeNode == "TEX_IMAGE"):
                image = socket.links[0].from_node.image
                value = image
    else:
        if(type == "COLOR"): #Input with RGB Input Color
            rgb = intSocket.default_value[:] # Comportamento normal
            v1 = to_hex(rgb[0])[2:]
            v1 = str(v1).zfill(2)
            v2 = to_hex(rgb[1])[2:]
            v2 = str(v2).zfill(2)
            v3 = to_hex(rgb[2])[2:]
            v3 = str(v3).zfill(2)
            
            value = (v1+v2+v3).upper()
        
        if(type == "FLOAT"):
            value = intSocket.default_value
            
        if(type == "BOOL"):
            value = intSocket.default_value
            
        if(type == "KEY"):
            value = intSocket.default_value  
            
        if(type == "TEXTURE"):
            typeNode =intSocket.type
            if(typeNode == "TEX_IMAGE"):
                value = intSocket.default_value

    return value
    
def CheckMaterial(mat):
    rootNode = None
    for n in mat.node_tree.nodes:
        if('BSDF_PRINCIPLED' == n.type and mat.B2U_Material_Settings.mode == "Principled"):
            rootNode = n
            return True
        if('BSDF_DIFFUSE' == n.type and mat.B2U_Material_Settings.mode == "Diffuse"):
            rootNode = n
            return True
            
        if('EMISSION' == n.type and mat.B2U_Material_Settings.mode == "Emission"):
            rootNode = n
            return True

    if(rootNode == None ):
        return False;
        
# Export Objects
def B2U_ExportFunction():
    print("------------------------- Start B2U Export Process ----------------------------")
    # Inicializa o Reports
    reports = ""

    # --------- Estrutura de Pastas ------------------
    if bpy.context.scene.B2U_Settings.name != "":
        scene_name = bpy.context.scene.B2U_Settings.name
    else:
        scene_name = bpy.context.scene.name
    
    exportPath = bpy.context.scene.B2U_Settings.exportPath
    print(exportPath)
    if(bpy.context.scene.B2U_Settings.exportAutoGeneratePath and exportPath == ""):
        reports += "ERROR: The Export Path is not valid $%"
        return reports
    exportPath.encode("unicode-escape")
    exportPath = exportPath.replace("\\","/")
    if(exportPath.endswith("/")):
        exportPath = exportPath[:-1]
    
    # Cria diretorios
    if(bpy.context.scene.B2U_Settings.exportAutoGeneratePath):
        Base_Dir = exportPath + "/" + scene_name
        Materials_Dir = Base_Dir + "/" + "Materials"
        Texture_Dir = Base_Dir + "/" + "Textures"
        Models_Dir = Base_Dir + "/" + "Prefabs"
        Scene_Dir = Base_Dir + "/"   

        if(not os.path.exists(Base_Dir)):
            os.makedirs(Base_Dir)
            reports += "Directory: Created Base Directory $%"
            
        if(not os.path.exists(Models_Dir)):
            os.makedirs(Models_Dir)
            reports += "Directory: Created Models Directory $%"
        if(not os.path.exists(Materials_Dir)):
            os.makedirs(Materials_Dir)
            reports += "Directory: Created Materials Directory $%"
        if(not os.path.exists(Texture_Dir)):
            os.makedirs(Texture_Dir)
            reports += "Directory: Created Texture Directory $%"
        
        if((bpy.context.scene.B2U_Settings.use_scene)):
            if(not os.path.exists(Scene_Dir)):
                os.makedirs(Scene_Dir)
                reports += "Directory: Created Scene Directory $%"
    
    else:
        Models_Dir = bpy.context.scene.B2U_Settings.modelsPath
        Materials_Dir = bpy.context.scene.B2U_Settings.materialsPath
        Texture_Dir = bpy.context.scene.B2U_Settings.texturePath       
        
        if(bpy.context.scene.B2U_Settings.use_scene):
            Scene_Dir = bpy.context.scene.B2U_Settings.scenePath
     
        # Always create folders if needed
        if not os.path.exists(Models_Dir):
            os.makedirs(Models_Dir)
            reports += "Directory: Created Models Directory $%"
            
        if not os.path.exists(Materials_Dir):
            os.makedirs(Materials_Dir)
            reports += "Directory: Created Materials Directory $%"
            
        if not os.path.exists(Texture_Dir): 
            os.makedirs(Texture_Dir)
            reports += "Directory: Created Texture Directory $%"
        
        if(bpy.context.scene.B2U_Settings.use_scene):
            if not os.path.exists(Scene_Dir):
                os.makedirs(Scene_Dir)
                reports += "Directory: Created Scene Directory $%"
                
    # If Automatic Folder Struct the assetsPath will be find based on the export path
    if(bpy.context.scene.B2U_Settings.exportAutoGeneratePath):
        assetsPath = exportPath.split("Assets")[0] + "Assets"
        assetsPath.encode("unicode-escape")
        assetsPath = assetsPath.replace("\\","/")
        if(assetsPath.endswith("/")):
            assetsPath = assetsPath[:-1]
        if(not os.path.exists(assetsPath)):
            reports += "ERROR: Make sure you selected a path inside the Assets folder of a Unity Project $%"
    else:
        assetsPath = Models_Dir.split("Assets")[0] + "Assets"
        assetsPath.encode("unicode-escape")
        assetsPath = assetsPath.replace("\\","/")
        if(assetsPath.endswith("/")):
            assetsPath = assetsPath[:-1]
        if(not os.path.exists(assetsPath)):
            reports += "ERROR: Make sure you selected a path inside the Assets folder of a Unity Project $%"
    
    # If the Data Path do not exist create it
    if(not os.path.exists(assetsPath +"/B2U/Editor/Data/")):
        os.makedirs(assetsPath +"/B2U/Editor/Data")
        
    # If the Data Path do not exist create it
    if(not os.path.exists(assetsPath +"/B2U/Editor/Data/Prefabs/")):
        os.makedirs(assetsPath +"/B2U/Editor/Data/Prefabs")
        
    # If the Data Path do not exist create it
    if(not os.path.exists(assetsPath +"/B2U/Editor/Data/Materials/")):
        os.makedirs(assetsPath +"/B2U/Editor/Data/Materials")
        
    # If the Data Path do not exist create it
    if(not os.path.exists(assetsPath +"/B2U/Editor/Data/Groups/")):
        os.makedirs(assetsPath +"/B2U/Editor/Data/Groups")
    
    # If the Export Path do not exist create it
    if(bpy.context.scene.B2U_Settings.exportAutoGeneratePath):
        if(not os.path.exists(bpy.context.scene.B2U_Settings.exportPath)):
            os.makedirs(bpy.context.scene.B2U_Settings.exportPath)
            reports += "Directory: Base Directory $%"
    
    # Paths Locais
    if(bpy.context.scene.B2U_Settings.exportAutoGeneratePath):
    
        localPath = exportPath[exportPath.find("Asset"):]
        localPath.replace('\\', '/');
        
        Base_Local = localPath + "/" + scene_name
        Models_Local = Base_Local + "/" + "Prefabs"
        Materials_Local = Base_Local + "/" + "Materials"
        Textures_Local = Base_Local + "/" + "Textures"
        
    else:
        Base_Local = bpy.context.scene.B2U_Settings.prefabsPath[bpy.context.scene.B2U_Settings.prefabsPath.find("Asset"):]
        Models_Local = bpy.context.scene.B2U_Settings.modelsPath[bpy.context.scene.B2U_Settings.modelsPath.find("Asset"):]
        Materials_Local = bpy.context.scene.B2U_Settings.materialsPath[bpy.context.scene.B2U_Settings.materialsPath.find("Asset"):]
        Textures_Local = bpy.context.scene.B2U_Settings.texturePath[bpy.context.scene.B2U_Settings.texturePath.find("Asset"):]
        
    Models_Local.encode("unicode-escape")
    Models_Local = Models_Local.replace("\\","/")
    if(Models_Local.endswith("/")):
        Models_Local = Models_Local[:-1]
    
    Materials_Local.encode("unicode-escape")
    Materials_Local = Materials_Local.replace("\\","/")
    if(Materials_Local.endswith("/")):
        Materials_Local = Materials_Local[:-1]
    
    Textures_Local.encode("unicode-escape")
    Textures_Local = Textures_Local.replace("\\","/")
    if(Textures_Local.endswith("/")):
        Textures_Local = Textures_Local[:-1]
        
        
    # --------------- Cria Scene ---------------------
    if(bpy.context.scene.B2U_Settings.use_scene):
        path_scenefile = Scene_Dir + "/" + scene_name + ".b2us"

        # Cria Xml da cena
        out_file = open(path_scenefile,"w")
        out_file.close()
        
        scene = ET.Element("Scene")
    
    # --------------- Cria Prefabs ---------------------
    Prefabs = []
    PrefabObjs = []
    
    # Set if will export the scene or only selected objects
    if bpy.context.scene.B2U_Settings.selected:
        ObjectsToExportTemp = bpy.context.selected_objects
    else:
        ObjectsToExportTemp = bpy.context.scene.objects
        
    # Remove Objetos que estão marcados como não exportar no Object Properties
    ObjectsToExport = []
    for Obj in ObjectsToExportTemp:
        if Obj.B2U_Objects_Settings.export and (Obj in bpy.context.visible_objects):
            ObjectsToExport.append(Obj)
        
    # Lista de Prefabs
    for Obj in ObjectsToExport:
        if Obj.type == 'MESH':
            if Obj.data.name not in Prefabs:
                Prefabs.append(Obj.data.name)
                PrefabObjs.append(Obj)
    
    ProxyList = []
    
    # Clean and Check for Object Showstopper Conditions
    isValid = True
    REPORTMatUnsued = []
    for Pref in PrefabObjs:
        # Clear unused materials.
        if(len(Pref.material_slots) > 0):
            count = len(Pref.material_slots)
            i = 0
            while(i < count or count == 0 ):
                try:
                    if(Pref.material_slots[i].material == None):
                        Pref.data.materials.pop(i)
                        REPORTMatUnsued.append(Pref)
                    else:
                        i += 1
                except:
                    break

        if(len(Pref.data.materials) == 0):
            isValid = False
            reports += "ERROR: Object " + Pref.name + " don't have materials $%"
        for mat in Pref.data.materials:
            if(mat.node_tree == None):
                isValid = False
                reports += "ERROR: Object " + Pref.name + " have not node materials $%"
            if(not CheckMaterial(mat)):
                isValid = False
                reports += "ERROR: Object " + Pref.name + "Has one or more materials with problems $%"
    if not isValid:
        return reports
    
    # Print nonCritical Unused materials fixed
    REPORTMatUnsued = set(REPORTMatUnsued)
    for Pref in REPORTMatUnsued:
        reports += "Materials: Fixed non used socket materials on: " + str(Pref.name) + " $%"

    # fix materials with / in the name
    for mat in Pref.data.materials:
        mat.name = mat.name.replace("/", "")
        mat.name = mat.name.replace("//", "")
        mat.name = mat.name.replace("\\", "")
    
    texSaveCache = [] # Start the texCache used to save package images just once
    
    # Process the Apply SimplePrefabFix (Apply Rot,Scale) values to single mesh user objects
    for Prefab in PrefabObjs:
        if(Prefab.data.users == 1 and (bpy.context.scene.B2U_Settings.applyTransform)):
            bpy.ops.object.select_all(action='DESELECT')
            Prefab.select = True
            bpy.context.scene.objects.active = Prefab
            bpy.ops.object.transform_apply(location = False, scale = True, rotation = True)
        
    
    # For each prefab start the export process
    for Prefab in PrefabObjs:
        # Desseleciona todos os objetos
        for Obj in bpy.context.scene.objects:
            Obj.select = False
        
        Prefab_name = Prefab.data.name

        # Cria um proxy que será selecionado
        proxy = duplicateObject(bpy.context.scene,bpy.context.scene.B2U_Settings.prefixPrefab+Prefab_name,Prefab)
                
        bpy.context.scene.objects.active = proxy
        ProxyList.append(proxy)
        
        area = bpy.context.area
        old_type = area.type
        area.type = 'VIEW_3D'
        
        # Corrige a rotação
        proxy.rotation_euler = (math.radians(-90),math.radians(180),0)
        
        # Corrige a escala
        proxy.scale = (100,100,100)

        bpy.ops.object.transform_apply(rotation=True,scale=True)
        
        # Cria UV Placeholder no modelo caso não exista nenhuma
        if(len(proxy.data.uv_textures) == 0):
            proxy.data.uv_textures.new(name="UVMap")
            proxy.data.update()
        
        bpy.ops.export_scene.fbx(   filepath = Models_Dir +"/" + bpy.context.scene.B2U_Settings.prefixPrefab + Prefab_name+".fbx",
                                    use_selection=True,                                    
                                    axis_forward='-Z',
                                    axis_up='Y',
                                    global_scale = 1.0,
                                    use_mesh_modifiers = True
                                )
        area.type = old_type
        

        # Escreve XML do Prefab
        # Cria o xml do prefab
        path_prefabfile = assetsPath +"/B2U/Editor/Data/Prefabs/" + bpy.context.scene.B2U_Settings.prefixPrefab + Prefab_name+".b2up"
        out_file_prefab = open(path_prefabfile,"w")
        out_file_prefab.close()
        
        prefab_root = ET.Element("Prefab")
        materials = ET.SubElement(prefab_root,"Materials")
        
        # Prefab Parameters
        tag = ET.SubElement(prefab_root,"Tag").text = Prefab.data.B2U_Prefab_Settings.tag
        layer = ET.SubElement(prefab_root,"Layer").text = Prefab.data.B2U_Prefab_Settings.layer
        static = ET.SubElement(prefab_root,"Static").text = str(Prefab.data.B2U_Prefab_Settings.static)
        collider = ET.SubElement(prefab_root,"Collider").text = str(Prefab.data.B2U_Prefab_Settings.collider)
        uv2 = ET.SubElement(prefab_root,"UV2").text = str(Prefab.data.B2U_Prefab_Settings.generateUV2)

        # Check if it's ok... Process the Material and Texture exports
        if(len(Prefab.material_slots) > 0):
                      
            for idx,mat_slt in enumerate(Prefab.material_slots):
                mat = mat_slt.material
                material = ET.SubElement(materials,"Mat")
                ET.SubElement(material,"Name").text = str(mat.name)
                ET.SubElement(material, "Path").text = str(Materials_Local)
                rewrite = bpy.context.scene.B2U_Settings.mat_update
                
                # Create Material Xml -------------------------------------------
                #path_matfile = Materials_Dir + "/" + mat.name +".b2mat"
                path_matfile = assetsPath + "/B2U/Editor/Data/Materials/" + mat.name +".b2mat" # New in 0.4
                mat_exist = os.path.exists(path_matfile)
                # Cria e/ou atualiza o arquivo metadata caso ele não exista, rewrite esteja ligado
 
                
                if((not mat_exist) or rewrite):
                    out_file_mat = open(path_matfile,"w")
                    out_file_mat.close()
                
                    mat_root = ET.Element(mat.name)
                    
                    # Easy Principled Shader
                    if(mat.B2U_Material_Settings.mode == "Principled"):
                        ET.SubElement(mat_root, "Shader").text = str(mat.B2U_Material_Settings.shaderPrincipled)
                        ET.SubElement(mat_root, "MaterialMode").text = str(mat.B2U_Material_Settings.mode)
                        ET.SubElement(mat_root,"Rewrite").text = str(rewrite)
                        mat_shaderChannels = ET.SubElement(mat_root,"Channels")
                        rootNode = None
                        for n in mat.node_tree.nodes:
                            if('BSDF_PRINCIPLED' == n.type):
                                rootNode = n
                                break

                        if(rootNode != None):
                            
                            # Handle Albedo Texture and Base Color ------------------------------------------------------------------
                            image = GetDirectData(GetInputSocketByName(rootNode,'Base Color'),"TEXTURE")
                            
                            if(image != None):
                                finalPath = ExportTexture(image,texSaveCache,Texture_Dir,Textures_Local)
                                if(finalPath != ""):
                                    # Export XML
                                    ET.SubElement(mat_shaderChannels,"_MainTex").text = "Texture" + "," + "COLOR" + "," + finalPath
                                    ET.SubElement(mat_shaderChannels,"_Color").text = "Color" + "," + "#FFFFFF"

                            else:
                                # Use Base Color
                                hex = GetDirectData(GetInputSocketByName(rootNode,'Base Color'),"COLOR")
                                ET.SubElement(mat_shaderChannels,"_Color").text = "Color" + "," + "#" + hex
                                ET.SubElement(mat_shaderChannels,"_MainTex")

                            
                            # Handle Metallic ------------------------------------------------------------------
                            image = GetDirectData(GetInputSocketByName(rootNode,'Metallic'),"TEXTURE")
                            
                            if(image != None):
                                finalPath = ExportTexture(image,texSaveCache,Texture_Dir,Textures_Local)
                                if(finalPath != ""):
                                    # Export XML    
                                    ET.SubElement(mat_shaderChannels,"_Metallic").text = "Float" + ",0.0" 
                                    ET.SubElement(mat_shaderChannels,"_MetallicGlossMap").text = "Texture" + "," + "COLOR" + "," + finalPath
                            
                            else:
                                float = GetDirectData(GetInputSocketByName(rootNode,'Metallic'),"FLOAT")
                                ET.SubElement(mat_shaderChannels,"_Metallic").text = "Float" + "," + str(float)
                                ET.SubElement(mat_shaderChannels,"_MetallicGlossMap")
                                
                            # Handle Roughness ------------------------------------------------------------------
                            image = GetDirectData(GetInputSocketByName(rootNode,'Roughness'),"TEXTURE")
                            
                            if(image != None):
                                finalPath = ExportTexture(image,texSaveCache,Texture_Dir,Textures_Local)
                                if(finalPath != ""):
                                    # Export XML
                                    ET.SubElement(mat_shaderChannels,"_Glossiness").text = "Float" + ",0.0" 
                                    ET.SubElement(mat_shaderChannels,"_SpecGlossMap").text = "Texture" + "," + "COLOR" + "," + finalPath
                            
                            else:
                                float = GetDirectData(GetInputSocketByName(rootNode,'Roughness'),"FLOAT")
                                ET.SubElement(mat_shaderChannels,"_Glossiness").text = "Float" + "," + str(float)
                                ET.SubElement(mat_shaderChannels,"_SpecGlossMap")
                                
                                

                            # Handle Keys
                            ET.SubElement(mat_shaderChannels,"_SpecularHighlights").text = "Float" + "," + "1.0"
                            ET.SubElement(mat_shaderChannels,"_GlossyReflections").text = "Float" + "," + "1.0"
                                
                                
                            # Handle Normal ------------------------------------------------------------------
                            
                            normalNode = None
                            for n in mat.node_tree.nodes:
                                if('NORMAL_MAP' == n.type):
                                    normalNode = n
                                    break
                            
                            if(normalNode != None):
                                print("Here")
                                image = GetDirectData(GetInputSocketByName(normalNode,'Color'),"TEXTURE")
                                print(image)
                                if(image != None):
                                    
                                    finalPath = ExportTexture(image,texSaveCache,Texture_Dir,Textures_Local)
                                    print(finalPath)
                                    if(finalPath != ""):
                                        # Export XML
                                        ET.SubElement(mat_shaderChannels,"_BumpMap").text = "Texture" + "," + "NORMAL" + "," + finalPath
                                
                                else:
                                    ET.SubElement(mat_shaderChannels,"_BumpMap")

                            else:
                                ET.SubElement(mat_shaderChannels,"_BumpMap")
                                
                                
                            # Handle Emission ------------------------------------------------------------------
                            
                            emissionNode = None
                            for n in mat.node_tree.nodes:
                                if('EMISSION' == n.type):
                                    emissionNode = n
                                    break
                            
                            if(emissionNode != None):
                                image = GetDirectData(GetInputSocketByName(emissionNode,'Color'),"TEXTURE")
                                if(image != None):
                                    print(image)
                                    finalPath = ExportTexture(image,texSaveCache,Texture_Dir,Textures_Local)
                                    if(finalPath != ""):
                                        # Export XML
                                        ET.SubElement(mat_shaderChannels,"_EmissionColor").text = "Color" + "," + "#FFFFFF"
                                        ET.SubElement(mat_shaderChannels,"_EmissionMap").text = "Texture" + "," + "COLOR" + "," + finalPath
                                
                                else:
                                    ET.SubElement(mat_shaderChannels,"_EmissionMap")
                                    # Use Emission Color
                                    hex = GetDirectData(GetInputSocketByName(rootNode,'Color'),"COLOR")
                                    ET.SubElement(mat_shaderChannels,"_EmissionColor").text = "Color" + "," + "#" + hex
                            else:
                                ET.SubElement(mat_shaderChannels,"_EmissionMap")
                                ET.SubElement(mat_shaderChannels,"_EmissionColor")
                                
                                
                            # Handle Transparent ------------------------------------------------------------------
                            transparentNode = None
                            for n in mat.node_tree.nodes:
                                if('BSDF_TRANSPARENT' == n.type):
                                    transparentNode = n
                                    break
                            
                            if(transparentNode != None):
                                ET.SubElement(mat_shaderChannels,"_Transparent").text = mat.B2U_Material_Settings.transparentMode
                            else:
                                ET.SubElement(mat_shaderChannels,"_Transparent").text = "Opaque"
                                
                        indent(mat_root)
                        FileOut = ET.ElementTree(mat_root)
                        FileOut.write(path_matfile)
                        
                    # EMISSION MATERIAL -------------------------------------------------------------------------------------------------------------------------------------    
                    if(mat.B2U_Material_Settings.mode == "Emission"):
                        ET.SubElement(mat_root, "Shader").text = str(mat.B2U_Material_Settings.shaderEmission)
                        ET.SubElement(mat_root, "MaterialMode").text = str(mat.B2U_Material_Settings.mode)
                        ET.SubElement(mat_root,"Rewrite").text = str(rewrite)
                        mat_shaderChannels = ET.SubElement(mat_root,"Channels")
                        rootNode = None
                        for n in mat.node_tree.nodes:
                            if('EMISSION' == n.type):
                                rootNode = n
                                break
                        if(rootNode != None):
                            
                            # Handle Albedo Texture and Base Color ------------------------------------------------------------------
                            image = GetDirectData(GetInputSocketByName(rootNode,'Color'),"TEXTURE")
                            if(image != None):
                                finalPath = ExportTexture(image,texSaveCache,Texture_Dir,Textures_Local)
                                if(finalPath != ""):
                                    # Export XML
                                    ET.SubElement(mat_shaderChannels,"_MainTex").text = "Texture" + "," + "COLOR" + "," + finalPath
                                    ET.SubElement(mat_shaderChannels,"_Color").text = "Color" + "," + "#FFFFFF"
                            
                            else:
                                # Use Base Color
                                hex = GetDirectData(GetInputSocketByName(rootNode,'Color'),"COLOR")
                                ET.SubElement(mat_shaderChannels,"_Color").text = "Color" + "," + "#" + hex
                                ET.SubElement(mat_shaderChannels,"_MainTex")
                                

                        indent(mat_root)
                        FileOut = ET.ElementTree(mat_root)
                        FileOut.write(path_matfile)    
                    
                        
                    # DIFFUSE MATERIAL -------------------------------------------------------------------------------------------------------------------------------------
                    if(mat.B2U_Material_Settings.mode == "Diffuse"):
                        ET.SubElement(mat_root, "Shader").text = str(mat.B2U_Material_Settings.shaderDiffuse)
                        ET.SubElement(mat_root, "MaterialMode").text = str(mat.B2U_Material_Settings.mode)
                        ET.SubElement(mat_root,"Rewrite").text = str(rewrite)
                        mat_shaderChannels = ET.SubElement(mat_root,"Channels")
                        rootNode = None
                        for n in mat.node_tree.nodes:
                            if('BSDF_DIFFUSE' == n.type):
                                rootNode = n
                                break
                        if(rootNode != None):
                            
                            # Handle Albedo Texture and Base Color ------------------------------------------------------------------
                            image = GetDirectData(GetInputSocketByName(rootNode,'Color'),"TEXTURE")
                            if(image != None):
                                finalPath = ExportTexture(image,texSaveCache,Texture_Dir,Textures_Local)
                                if(finalPath != ""):
                                    # Export XML
                                    ET.SubElement(mat_shaderChannels,"_MainTex").text = "Texture" + "," + "COLOR" + "," + finalPath
                                    ET.SubElement(mat_shaderChannels,"_Color").text = "Color" + "," + "#FFFFFF"
                            
                            else:
                                # Use Base Color
                                hex = GetDirectData(GetInputSocketByName(rootNode,'Color'),"COLOR")
                                ET.SubElement(mat_shaderChannels,"_Color").text = "Color" + "," + "#" + hex
                                ET.SubElement(mat_shaderChannels,"_MainTex")
                            
                            # Handle Transparent ------------------------------------------------------------------
                            transparentNode = None
                            for n in mat.node_tree.nodes:
                                if('BSDF_TRANSPARENT' == n.type):
                                    transparentNode = n
                                    break
                            
                            if(transparentNode != None):
                                ET.SubElement(mat_shaderChannels,"_Transparent").text = mat.B2U_Material_Settings.transparentMode
                            else:
                                ET.SubElement(mat_shaderChannels,"_Transparent").text = "Opaque"
                                

                        indent(mat_root)
                        FileOut = ET.ElementTree(mat_root)
                        FileOut.write(path_matfile)
 
            
        # Save the Prefab XML
        indent(prefab_root)
        FileOut = ET.ElementTree(prefab_root)
        FileOut.write(path_prefabfile)              

    # Desseleciona todos os objetos
    for Obj in bpy.context.scene.objects:
        Obj.select = False
    
    # Exclui todos os proxys
    for Obj in ProxyList:
        Obj.select = True
    bpy.ops.object.delete()
    
    # -------------- Cria XML dos Grupos -------------
    if(bpy.context.scene.B2U_Settings.use_group):
        for group in bpy.data.groups:
            #path_group = Groups_Dir + "/" + group.name +".b2group"
            path_group = assetsPath + "/B2U/Editor/Data/Groups/" + group.name +".b2ug"
            out_file_group = open(path_group,"w")
            out_file_group.close()
            
            group_root = ET.Element("Group")
            #ET.SubElement(group_root, "Path").text = Groups_Local + "/" + group.name + ".b2ug"
            ET.SubElement(group_root,"Path").text = Models_Local + "/" + group.name + ".prefab"
            ET.SubElement(group_root,"NoCache").text = str(random.randrange(0,10000)) # Force makes a diferent file so always reimport the group
            for Obj in bpy.context.scene.objects:
                if(Obj.type != "MESH"):continue
                
                if(group in Obj.users_group):
                    loc, rot, sca = Obj.matrix_world.decompose()
                    rot = rot.to_euler()
                    parent = Obj.parent
                    # The scale is always local in Unity
                    sca = Obj.scale
            
                    Pos =  [ round(elem, 5) for elem in loc]
                    Rot = [ round(elem, 5) for elem in rot ]
                    Sca = [ round(elem, 5) for elem in sca ]
                    Prefab = Obj.data.name
                    
                    vec = mathutils.Euler((Rot[0],Rot[1],Rot[2]),"XYZ")
                    euler_final = vec.to_matrix()
                    euler_final = euler_final.to_euler("XZY")
                    
                    obj = ET.SubElement(group_root, "Object")
                    
                    ET.SubElement(obj, "Name").text = str(Obj.name)
                    ET.SubElement(obj, "Prefab").text = str(Models_Local + "/" + bpy.context.scene.B2U_Settings.prefixPrefab + Prefab + ".fbx")
                    ET.SubElement(obj, "Position").text = str((Pos[0],Pos[2],Pos[1]))
                    ET.SubElement(obj, "Rotation").text = str((math.degrees(euler_final[0]),math.degrees(euler_final[1]),math.degrees(euler_final[2])))
                    ET.SubElement(obj, "Scale").text = str((Sca[0],Sca[2],Sca[1]))
                    
                    parent = Obj.parent
                    if parent == None:
                        parent_name = "None"
                    else:
                        parent_name = parent.name
                    
                    ET.SubElement(obj, "Parent").text = str(parent_name)

            indent(group_root)
            FileOut = ET.ElementTree(group_root)
            FileOut.write(path_group)
            
    # ------------- Cria XML da Cena -----------------
    if(bpy.context.scene.B2U_Settings.use_scene):
        
        scene = ET.Element("Scene")
        data_scene = ET.SubElement(scene,"Parameters")
        ET.SubElement(data_scene,"Name").text = scene_name
                
        obj_scene = ET.SubElement(scene,"Objects")
        lamp_scene = ET.SubElement(scene,"Lamps")
        cam_scene = ET.SubElement(scene,"Cameras")
        
        for Obj in ObjectsToExport:
        
            # Export Objects
            if Obj.type == "MESH":
                               
                loc, rot, sca = Obj.matrix_world.decompose()
                rot = rot.to_euler()

                # The scale is always local in Unity
                sca = Obj.scale
        
                Pos =  [ round(elem, 5) for elem in loc]
                Rot = [ round(elem, 5) for elem in rot ]
                Sca = [ round(elem, 5) for elem in sca ]
                Prefab = Obj.data.name
                
                vec = mathutils.Euler((Rot[0],Rot[1],Rot[2]),"XYZ")
                euler_final = vec.to_matrix()
                euler_final = euler_final.to_euler("XZY")
                
                obj = ET.SubElement(obj_scene, "Object")
                ET.SubElement(obj, "Name").text = str(Obj.name)
                ET.SubElement(obj, "Prefab").text = str(Models_Local + "/" + bpy.context.scene.B2U_Settings.prefixPrefab + Prefab + ".fbx")
                ET.SubElement(obj, "Position").text = str((Pos[0],Pos[2],Pos[1]))
                ET.SubElement(obj, "Rotation").text = str((math.degrees(euler_final[0]),math.degrees(euler_final[1]),math.degrees(euler_final[2])))
                ET.SubElement(obj, "Scale").text = str((Sca[0],Sca[2],Sca[1]))
                
                # Overwrited parameters per object
                ET.SubElement(obj, "Static").text = str(Obj.B2U_Objects_Settings.static)
                ET.SubElement(obj, "Layer").text = str(Obj.B2U_Objects_Settings.layer)
                ET.SubElement(obj, "Tag").text = str(Obj.B2U_Objects_Settings.tag)
                
                parent = Obj.parent
                if parent == None:
                    parent_name = "None"
                else:
                    parent_name = parent.name
                
                ET.SubElement(obj, "Parent").text = str(parent_name)
            
            if(bpy.context.scene.B2U_Settings.use_lights):
                # Export Lamps
                if Obj.type == "LAMP":
                    if(Obj.data.node_tree == None):
                        reports += "WARNING! The Light Object '" + Obj.name + "' is not a Valid. $%"
                        continue
                        
                    loc, rot, sca = Obj.matrix_world.decompose()
                    rot = rot.to_euler()
            
                    Pos =  [ round(elem, 5) for elem in loc]
                    Rot = [ round(elem, 5) for elem in rot ]
                    
                    vec = mathutils.Euler((Rot[0],Rot[1],Rot[2]),"XYZ")
                    euler_final = vec.to_matrix()
                    euler_final = euler_final.to_euler("XZY")
                    
                    obj = ET.SubElement(lamp_scene, "Lamp")
                    ET.SubElement(obj, "Name").text = str(Obj.name)
                    ET.SubElement(obj, "Position").text = str((Pos[0],Pos[2],Pos[1]))
                    ET.SubElement(obj, "Rotation").text = str((math.degrees(euler_final[0]),math.degrees(euler_final[1]),math.degrees(euler_final[2])))
                    
                    color = str((1,1,1))
                    power = str(20.0)
                    
                    for n in Obj.data.node_tree.nodes:
                        #Direct Interface Outside Node Group
                        if("Emission" in n.bl_idname):
                            color = "#" + GetDirectData(n.inputs["Color"],"COLOR")
                            power = GetDirectData(n.inputs["Strength"],"FLOAT")
                    
                    ET.SubElement(obj, "Color").text = str(color[:])
                    ET.SubElement(obj, "Power").text = str(power)
                    
                    ET.SubElement(obj, "Type").text = str(Obj.data.type)
                    
                    
                    if(Obj.data.type == "SPOT"):
                        ET.SubElement(obj, "SpotSize").text = str(math.degrees(Obj.data.spot_size))
                        
                    parent = Obj.parent
                    if parent == None:
                        parent_name = "None"
                    else:
                        parent_name = parent.name
                    
                    ET.SubElement(obj, "Parent").text = str(parent_name)

            if(bpy.context.scene.B2U_Settings.use_cam):  
                # Export Cameras
                if Obj.type == "CAMERA":

                    loc, rot, sca = Obj.matrix_world.decompose()
                    rot = rot.to_euler()
            
                    Pos =  [ round(elem, 5) for elem in loc]
                    Rot = [ round(elem, 5) for elem in rot ]
                    
                    vec = mathutils.Euler((Rot[0],Rot[1],Rot[2]),"XYZ")
                    euler_final = vec.to_matrix()
                    euler_final = euler_final.to_euler("XYZ")
                    
                    obj = ET.SubElement(cam_scene, "Camera")
                    ET.SubElement(obj, "Name").text = str(Obj.name)
                    ET.SubElement(obj, "Position").text = str((Pos[0],Pos[2],Pos[1]))
                    ET.SubElement(obj, "Rotation").text = str((math.degrees(euler_final[0]),math.degrees(euler_final[1]),math.degrees(euler_final[2])))
                    ET.SubElement(obj, "Projection").text = str(Obj.data.type)
                    ET.SubElement(obj, "Fov").text = str("{0:.2f}".format(math.degrees(Obj.data.angle)))
                    ET.SubElement(obj, "Near").text = str("{0:.2f}".format(Obj.data.clip_start))
                    ET.SubElement(obj, "Far").text = str("{0:.2f}".format(Obj.data.clip_end))
                    ET.SubElement(obj, "Size").text = str("{0:.2f}".format(Obj.data.ortho_scale))

                    parent = Obj.parent
                    if parent == None:
                        parent_name = "None"
                    else:
                        parent_name = parent.name
                    
                    ET.SubElement(obj, "Parent").text = str(parent_name)
                    
            indent(scene)
            
            FileOut = ET.ElementTree(scene)
            FileOut.write(path_scenefile)
    
    
    # retorna o reports
    return reports
    
# ---------------------------------------- DATA CLASSES --------------------------------------------       
class B2U_Objects_Settings(bpy.types.PropertyGroup):
    export = bpy.props.BoolProperty(description="Export or not this objects",default=True)
    static = bpy.props.EnumProperty(
        name="Object Mode:",
        description="The exported static setting",
        items=(('Keep', "Keep Prefab", ""),
               ('Static', "Static", ""),
               ('Dynamic', "Dynamic", "")
              ),
        default='Keep'
        )

    layer = bpy.props.StringProperty(description="Ovewrite the Prefab Layer Settings, None to keep",default="")
    tag = bpy.props.StringProperty(description= "Ovewrite the Prefab Tag Settings, None to keep", default="")
    scene_overwrite = bpy.props.BoolProperty(description="Ovewrite the Prefab Layer Settings",default=False)

class B2U_Prefab_Settings(bpy.types.PropertyGroup):
    static = bpy.props.EnumProperty(
        name="Object Mode:",
        description="The exported object mode",
        items=(('Static', "Static", ""),
               ('Dynamic', "Dynamic", "")
              ),
        default='Static'
        )
    layer = bpy.props.StringProperty(description="Set object to this layer name, it will be set to ""default"" if do not exist in unity",default="Default")
    tag = bpy.props.StringProperty(description= "Set object to use this tag, it will be set to "'Untagged'" if none or do not exist in unity", default = "Untagged")
    generateUV2 = bpy.props.BoolProperty(description="Generate automaticaly the UV2 in the imported prefab, used for lightmap generation", default = True)
    collider = bpy.props.EnumProperty(
                                        name = "Collider",
                                        description = "The collider to apply on object",
                                        items = (   ("None", "None", ""),
                                                    ("Box", "Box", ""),
                                                    ("Sphere", "Sphere", ""),
                                                    ("Capsule", "Capsule", ""),
                                                    ("Mesh", "Mesh", "")
                                                ),
                                                default = "Box"
                                                )

class B2U_Material_Settings(bpy.types.PropertyGroup):
    mode = bpy.props.EnumProperty(
                                        name = "Mode",
                                        description = "Base Material",
                                        items = (   
                                                    
                                                    ("Emission", "Emission", ""),
                                                    ("Diffuse", "Diffuse", ""),
                                                    ("Principled", "Principled", ""),
                                                    
                                                ),
                                                default = "Diffuse"
                                                )
                                                
    shaderPrincipled = bpy.props.EnumProperty(
                                        name = "ModePrincipled",
                                        description = "Use this shader in Unity",
                                        items = ( 
                                                    ("Autodesk Interactive", "PBR Material", ""),
                                                    ("Mobile/Diffuse", "Mobile Diffuse", ""),
                                                    ("Mobile/Bumped Diffuse", "Mobile Bumped Diffuse", ""),
                                                    ("Legacy Shaders/Transparent/Diffuse", "Legacy Transparent Diffuse", ""),
                                                    ("Unlit/Color", "Unlit Color", ""),
                                                    ("Unlit/Texture", "Unlit Texture", "")
                                                ),
                                                default = "Autodesk Interactive"
                                                )
                                                
    shaderEmission = bpy.props.EnumProperty(
                                        name = "ModeEmission",
                                        description = "Use this shader in Unity",
                                        items = ( 
                                                    ("Unlit/Color", "Unlit Color", ""),
                                                    ("Unlit/Texture", "Unlit Texture", "")
                                                ),
                                                default = "Unlit/Color"
                                                )
                                                
    shaderDiffuse = bpy.props.EnumProperty(
                                        name = "ModeDiffuse",
                                        description = "Use this shader in Unity",
                                        items = (
                                                    ("Autodesk Interactive", "PBR Material", ""),
                                                    ("Mobile/Diffuse", "Mobile Diffuse", ""),
                                                    ("Legacy Shaders/Transparent/Diffuse", "Legacy Transparent Diffuse", ""),
                                                    ("Unlit/Texture", "Unlit Texture", "")
                                                ),
                                                default = "Autodesk Interactive"
                                                )

    transparentMode = bpy.props.EnumProperty(
                                        name = "TransparentMode",
                                        description = "Use this transparentMode in Unity",
                                        items = (
                                                    ("Cutout", "Cutout", ""),
                                                    ("Fade", "Fade", ""),
                                                    ("Transparent", "Transparent", ""),
                                                    ("Opaque", "Opaque", ""),
                                                ),
                                                default = "Opaque"
                                                )
   
class B2U_Texture_Settings(bpy.types.PropertyGroup):
    channel = bpy.props.EnumProperty(   name = "Channel", 
                                        description = "The channel to apply this texture in Unity",
                                        items = (   ("_BumpMap","Normal Map","Assigned to _BumpMap Channel"),
                                                    ("_MetallicGlossMap","Metallic","Assigned to _MettalicGlossMap Channel"),
                                                    ("_OcclusionMap","Occlusion","Assigned to _MettalicGlossMap Channel"),
                                                    ("_MainTex","Diffuse/Albedo","Assigned to _MainTex Channel"),
                                                    ("_EmissionMap","Emission","Assigned to _Emission Channel"),
                                                    ("_ParallaxMap","Height Map","Assigned to _Parallax Channel"),
                                                    ("_DetailMask","Detail Mask","Assigned to _DetailMask Channel"),
                                                    ("_DetailAlbedoMap","Detail Albedo","Assigned to _DetailAlbedoMask Channel"),
                                                    ("_DetailNormalMap","Detail Normal Map","Assigned to _DetailNormalMap Channel"),
                                                    ("Custom","Custom","Defined by name")
                                                ),
                                                default = "_MainTex"
                                                )
    custom_channel = bpy.props.StringProperty(description= "Set a custom channel to apply",default="")

def set_exportPath(self,value):
    self["exportPath"] = bpy.path.abspath(value) 
def get_exportPath(self):
    try:
        return self['exportPath']
    except:
        return ""

def set_modelsPath(self,value):
    self["modelsPath"] = bpy.path.abspath(value)
def get_modelsPath(self):
    try:
        return self['modelsPath']
    except:
        return ""

def set_materialsPath(self,value):
    self["materialsPath"] = bpy.path.abspath(value)
    
def get_materialsPath(self):
    try:
        return self['materialsPath']
    except:
        return ""
    
def set_texturePath(self,value):
    self["texturePath"] = bpy.path.abspath(value)
    
def get_texturePath(self):
    try:
        return self['texturePath']
    except:
        return ""


def set_scenePath(self,value):
    self["scenePath"] = bpy.path.abspath(value)
    
def get_scenePath(self):
    try:
        return self['scenePath']
    except:
        return ""

class B2U_Settings(bpy.types.PropertyGroup):
    name = bpy.props.StringProperty(description = "Name of the exported scene, if Null will use the Blender's scene name",default="")
    prefixPrefab = bpy.props.StringProperty(description = "Prefix used to identify all B2U objects in Unity (WARNING! The Unity prefix identification need to mach this value)",default="_")
    use_scene = bpy.props.BoolProperty(description="Export Scene",default=True)
    use_lights = bpy.props.BoolProperty(description="Export lights",default=True)
    use_cam = bpy.props.BoolProperty(description="Export cameras",default=True)
    use_group = bpy.props.BoolProperty(description="Export Groups datafile",default=True)
    export_scene = bpy.props.BoolProperty(description="Export Scene", default = True)
    selected = bpy.props.BoolProperty(description="Export only selected objects",default=False)
    reports = bpy.props.StringProperty(description="",default="")
    mat_update = bpy.props.BoolProperty(description="Force material update from blender losing any modification made in unity",default=False)
    exportPath = bpy.props.StringProperty(description = "The Export Path to Export Files (WARNING! Always use absolute paths)",default="",subtype="DIR_PATH",get=get_exportPath,set=set_exportPath)
    exportAutoGeneratePath = bpy.props.BoolProperty(description = "If On auto generate folder structs in the Bsae Path", default = True)
    prefabsPath = bpy.props.StringProperty(description = "The base path to export",default="Prefabs",subtype="DIR_PATH")
    modelsPath = bpy.props.StringProperty(description = "The path to export models",default="Models",subtype="DIR_PATH",get=get_exportPath,set=set_exportPath)
    materialsPath = bpy.props.StringProperty(description = "The path to export materials",default="Materials",subtype="DIR_PATH",get=get_modelsPath,set=set_modelsPath)
    texturePath = bpy.props.StringProperty(description = "The path to export textures",default="Textures",subtype="DIR_PATH",get=get_texturePath,set=set_texturePath)
    #groupPath = bpy.props.StringProperty(description = "The path to export groups",default="Groups",subtype="DIR_PATH",get=get_groupPath,set=set_groupPath)
    scenePath = bpy.props.StringProperty(description = "The path to export scene files",default="Scenes",subtype="DIR_PATH",get=get_scenePath,set=set_scenePath)
    applyTransform = bpy.props.BoolProperty(description = "If It's not a Instance Apply Rot/Scale to the Blender Object and Final Prefab", default=True)
    textureFormat = bpy.props.EnumProperty( name ="Texture Format:", 
                                            description = "Format to save internal textures",
                                            items=( ("PNG","PNG (RGBA)",""),
                                                    ("JPEG","JPEG (RGB)",""),
                                                    ("TGA", "TGA (RGBA)",""),
                                                   ),
                                            default = "PNG"
                                            )
  
# ---------------------------------------- USER INTEFACE --------------------------------------------

def ShowMatData(mat,layout):
    
    baseNode = "None"
    _Color = ""
    _MainTex = "None"
    _Transparent = "None"
    _Metallic = 0
    _MetallicGlossMap = "None"
    _Glossiness = 0
    _SpecGlossMap = "None"
    _BumpMap = "None"
    _EmissionColor = "000000"
    _EmissionMap = "None"
    
    rootNode = None
    transpNode = None
    for n in mat.node_tree.nodes:
        if('BSDF_PRINCIPLED' == n.type and mat.B2U_Material_Settings.mode == "Principled"):
            rootNode = n
            break
        if('BSDF_DIFFUSE' == n.type and mat.B2U_Material_Settings.mode == "Diffuse"):
            rootNode = n
            break
        if('EMISSION' == n.type and mat.B2U_Material_Settings.mode == "Emission"):
            rootNode = n
            break
            
    for n in mat.node_tree.nodes:
        if('BSDF_TRANSPARENT' == n.type and (mat.B2U_Material_Settings.mode == "Principled" or mat.B2U_Material_Settings.mode == "Diffuse") ):
            transpNode = n
            break
        

    if(rootNode != None ):
        row = layout.row()
        row.label("Shader Data:",icon="MATERIAL" )
    
        baseNode = rootNode.name
        
        # PRINCIPLED
        if(rootNode.type == "BSDF_PRINCIPLED"):

            # Albedo / Color
            image = GetDirectData(GetInputSocketByName(rootNode,'Base Color'),"TEXTURE")
            if(image != None):
                _MainTex = image.name;
                
                #Transparent
                if(transpNode):
                    _Transparent = _MainTex
            
            else:
                _Color = GetDirectData(GetInputSocketByName(rootNode,'Base Color'),"COLOR") 
            
            
            
            # Metallic
            image = GetDirectData(GetInputSocketByName(rootNode,'Metallic'),"TEXTURE")
            if(image != None):
                _MetallicGlossMap = image.name;
            
            else:
                _Metallic = GetDirectData(GetInputSocketByName(rootNode,'Metallic'),"FLOAT") 
                
                
            # Roughness
            image = GetDirectData(GetInputSocketByName(rootNode,'Roughness'),"TEXTURE")
            if(image != None):
                _SpecGlossMap = image.name;
            
            else:
                _Glossiness = GetDirectData(GetInputSocketByName(rootNode,'Roughness'),"FLOAT") 
                
            #Normal Map
            normalNode = None
            for n in mat.node_tree.nodes:
                if('NORMAL_MAP' == n.type):
                    normalNode = n
                    break
           
            if(normalNode != None):
                image = GetDirectData(GetInputSocketByName(normalNode,'Color'),"TEXTURE")
                if(image != None):
                    _BumpMap = image.name

            # Roughness        
            emissionNode = None
            for n in mat.node_tree.nodes:
                if('EMISSION' == n.type):
                    emissionNode = n
                    break
                    
            # Emission
            if(emissionNode != None):
                image = GetDirectData(GetInputSocketByName(emissionNode,'Color'),"TEXTURE")
                if(image != None):
                    _EmissionMap = image.name
                else:
                    _EmissionColor = GetDirectData(GetInputSocketByName(emissionNode,'Color'),"COLOR") 
             
            
            box = layout.box()
            row = box.column()
            if(_MainTex != "None"):
                row.label("Albedo: " + _MainTex, icon= "TEXTURE" )
                if(transpNode):
                    row.label("Alpha: " + _Transparent, icon= "TEXTURE" )
            else:
                row.label("Albedo: " + _Color , icon = "COLOR")
            
            box = layout.box()
            row = box.column()
            if(_MetallicGlossMap != "None"):
                row.label("Metallic: " + _MetallicGlossMap,  icon= "TEXTURE")
            else:
                row.label("Metallic: " +"%6.3f " % _Metallic , icon = "LINENUMBERS_ON")
            
            box = layout.box()
            row = box.column()
            if(_SpecGlossMap != "None"):
                row.label("Roughness: " + _SpecGlossMap,  icon= "TEXTURE")
            else:
                row.label("Roughness: " + "%6.3f " % _Glossiness, icon = "LINENUMBERS_ON")
            
            box = layout.box()
            row = box.column()
            row.label("Normal Map: " +  _BumpMap,  icon= "TEXTURE")
            
            box = layout.box()
            row = box.column()
            if(_EmissionMap != "None"):
                row.label("Emission Map: " + _EmissionMap,  icon= "TEXTURE")
            else:
                row.label("Emission: " + _EmissionColor , icon = "COLOR")
         
         # DIFFUSE
        if(rootNode.type == "BSDF_DIFFUSE"):
        
            # Albedo / Color
            image = GetDirectData(GetInputSocketByName(rootNode,'Color'),"TEXTURE")
            if(image != None):
                _MainTex = image.name;
                
                #Transparent
                if(transpNode):
                    _Transparent = _MainTex
            
            else:
                _Color = GetDirectData(GetInputSocketByName(rootNode,'Color'),"COLOR") 
            
            box = layout.box()
            row = box.column()
            if(_MainTex != "None"):
                row.label("Color: " + _MainTex, icon= "TEXTURE" )
                if(transpNode):
                    row.label("Alpha: " + _Transparent, icon= "TEXTURE" )
            else:
                row.label("Color: " + _Color , icon = "COLOR")
    
    else:
        row = layout.row()
        row.label("Root Material not Found",icon="ERROR" )

 
def ShowReport(reports = "", message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        layout = self.layout
        sentences = reports.split(" $%")
        for sent in sentences:
            print(sent)
            if(sent != ""):
                if("Directory" in sent):
                    layout.label(sent, icon = "FILE_FOLDER")
                else:
                    if("Materials" in sent):
                        layout.label(sent, icon = "MATERIAL")
                    else:
                        layout.label(sent, icon = "ERROR")
                
        if(not "ERROR" in reports):
            layout.label("Export Process Finished", icon = "FILE_TICK")
        else:
            layout.label("Export Process Aborted", icon = "CANCEL")

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

    
class B2U_Export(bpy.types.Operator):
    """B2U Export Scene"""
    bl_idname = "b2u.export"
    bl_label = "Export"

    def execute(self, context):
        report = B2U_ExportFunction()
        ShowReport(report, "B2U Export", "B2U Exporter")
        return {'FINISHED'}
                                                       
class B2U_Texture_Panel(bpy.types.Panel):
    """B2U Texture Export Panel"""
    bl_label = "B2U Texture Settings"
    bl_idname = "B2U_Texture_Panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "texture"
    
    @classmethod
    def poll(cls, context):
        try:
            context.texture.image
            if(context.texture.image == None):
                return False
            return True
        except:
            return False
    
    def draw(self, context):
        layout = self.layout
        tex = context.texture
        layout.prop(tex.B2U_Texture_Settings,"channel", text = "Channel")
        if(tex.B2U_Texture_Settings.channel == "Custom"):
            layout.prop(tex.B2U_Texture_Settings,"custom_channel", text = "Channel Name")

class B2U_BasePanel(bpy.types.Panel):
    """B2U Export Panel"""
    bl_label = "B2U Exporter v1.3"
    bl_idname = "B2U_BasePanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_category="B2U"

    def draw(self, context):
        layout = self.layout
        
        scale = layout.row()
        scale.scale_y = 2
        scale.operator(B2U_Export.bl_idname, icon = "SAVE_COPY", text = "Export To Unity3D!")
        box = layout.box()
        box.label("Export Options:",icon = "FILTER")
        col = box.column(True)
        col.prop(bpy.context.scene.B2U_Settings,"selected", text = "Selected Objects",icon="HAND")
        col.prop(bpy.context.scene.B2U_Settings,"applyTransform", text = "Apply Transforms",icon="OBJECT_DATA")

        box.label("Export Components:",icon = "WORLD")
        row = box.row()
        col = row.column(True)
        col.prop(bpy.context.scene.B2U_Settings,"mat_update", text = "Material Update",icon="MATERIAL_DATA")
        
        col.prop(bpy.context.scene.B2U_Settings,"use_group", text = "Groups as Prefabs",icon="EXPORT")
        col.prop(bpy.context.scene.B2U_Settings,"use_scene", text = "Scene",icon="SCENE")

        if(bpy.context.scene.B2U_Settings.use_scene):
            col.prop(bpy.context.scene.B2U_Settings,"use_lights", text = "Lights",icon="OUTLINER_OB_LAMP")
            col.prop(bpy.context.scene.B2U_Settings,"use_cam", text = "Cameras",icon="CAMERA_DATA")
        
class B2U_SettingsPanel(bpy.types.Panel):
    """B2U Settings Panel"""
    bl_label = "General Settings"
    bl_idname = "B2U_SettingsPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_category="B2U"
    
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label("General Settings:",icon = "SCENE_DATA")
        box.prop(bpy.context.scene.B2U_Settings,"name", text = "Scene Name")
        
        box.prop(bpy.context.scene.B2U_Settings,"exportAutoGeneratePath", text = "Automatic Folder Struct")
        if(not bpy.context.scene.B2U_Settings.exportAutoGeneratePath):

            box.prop(bpy.context.scene.B2U_Settings,"modelsPath", text = "Prefabs Path")
            box.prop(bpy.context.scene.B2U_Settings,"materialsPath", text = "Materials Path")
            box.prop(bpy.context.scene.B2U_Settings,"texturePath", text = "TexturePath")

            if(bpy.context.scene.B2U_Settings.use_scene):
                box.prop(bpy.context.scene.B2U_Settings,"scenePath", text = "Scene Path")
        else:
            box.prop(bpy.context.scene.B2U_Settings,"exportPath", text = "Export Path")
        
        box.label("Advanced Settings:",icon = "ERROR")
        box.prop(bpy.context.scene.B2U_Settings,"prefixPrefab", text = "Prefix Identiication")
        
        box = layout.box()
        
        # Texture Settings
        box.label("Export Texture Settings:",icon = "TEXTURE")
        box.prop(bpy.context.scene.B2U_Settings,"textureFormat", text = "Save Format") 
  
class B2U_ObjectSettingsPanel(bpy.types.Panel):
    """B2U Settings Panel"""
    bl_label = "Object Settings"
    bl_idname = "B2U_ObjectSettingsPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_category="B2U"
    
    @classmethod
    def poll(cls, context):
        return (context.active_object != None) and (context.active_object.type == "MESH")
    
    def draw(self, context):
        layout = self.layout     
          
        box = layout.box()       
        box.label("Prefab Settings:",icon = "VIEW3D")
        box.prop(bpy.context.active_object.data,"name", text = "Prefab Name")            
        box.prop(bpy.context.active_object.data.B2U_Prefab_Settings,"generateUV2", text = "Generate Lightmap UV")
        box.prop(bpy.context.active_object.data.B2U_Prefab_Settings,"static", text = "Batching")
        box.prop(bpy.context.active_object.data.B2U_Prefab_Settings,"collider", text = "Collider")
        box.prop(bpy.context.active_object.data.B2U_Prefab_Settings,"layer", text = "Unity Layer")
        box.prop(bpy.context.active_object.data.B2U_Prefab_Settings,"tag", text = "Unity Tag")
            
        box = layout.box() 
        box.label("Scene Object Settings:",icon = "OUTLINER_OB_GROUP_INSTANCE")
        box.prop(bpy.context.active_object,"name", text = "Object Name")    
        box.prop(bpy.context.active_object.B2U_Objects_Settings,"export", text = "Export Object",icon="HAND")
             
        if(bpy.context.active_object.B2U_Objects_Settings.export):
            box.prop(bpy.context.active_object.B2U_Objects_Settings,"scene_overwrite", text = "Overwrite Prefab Settings")
            if(bpy.context.active_object.B2U_Objects_Settings.scene_overwrite):
                box.prop(bpy.context.active_object.B2U_Objects_Settings,"static", text = "Batching")
                box.prop(bpy.context.active_object.B2U_Objects_Settings,"layer", text = "Layer")
                box.prop(bpy.context.active_object.B2U_Objects_Settings,"tag", text = "Tag")

class B2U_Material(bpy.types.Panel):
    """B2U Material Settings"""
    bl_label = "B2U Material Settings"
    bl_idname = "B2U_Material_Panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "material"
    

    def draw(self, context):
        layout = self.layout
        mat = bpy.context.active_object.active_material
        if mat:
            layout.label("Unity Material Properties:",icon = "SCRIPTWIN")
            layout.prop(mat.B2U_Material_Settings,"mode", text = "Base Material",icon="MATERIAL")
            if(mat.B2U_Material_Settings.mode == "Principled"):
                layout.prop(mat.B2U_Material_Settings,"shaderPrincipled", text = "Unity Shader",icon="TEXTURE_SHADED")
            if(mat.B2U_Material_Settings.mode == "Emission"):
                layout.prop(mat.B2U_Material_Settings,"shaderEmission", text = "Unity Shader",icon="TEXTURE_SHADED")
            if(mat.B2U_Material_Settings.mode == "Diffuse"):
                layout.prop(mat.B2U_Material_Settings,"shaderDiffuse", text = "Unity Shader",icon="TEXTURE_SHADED")
                
            if(mat.B2U_Material_Settings.mode == "Diffuse" and mat.B2U_Material_Settings.shaderDiffuse == "Autodesk Interactive"):
                layout.prop(mat.B2U_Material_Settings,"transparentMode", text = "Transparent Mode",icon="TEXTURE_SHADED")
                
            if(mat.B2U_Material_Settings.mode == "Principled" and mat.B2U_Material_Settings.shaderPrincipled == "Autodesk Interactive" ):
                layout.prop(mat.B2U_Material_Settings,"transparentMode", text = "Transparent Mode",icon="TEXTURE_SHADED")
            
            ShowMatData(mat,layout)
                   
        
# --------------------------- REGISTER ---------------------------------------------------
def register():
    
    # Base Register
    bpy.utils.register_module(__name__)
   
    # Pointer Properties
    bpy.types.Scene.B2U_Settings = bpy.props.PointerProperty(type=B2U_Settings)
    bpy.types.Object.B2U_Objects_Settings = bpy.props.PointerProperty(type=B2U_Objects_Settings)
    bpy.types.Mesh.B2U_Prefab_Settings = bpy.props.PointerProperty(type=B2U_Prefab_Settings)
    bpy.types.Material.B2U_Material_Settings = bpy.props.PointerProperty(type=B2U_Material_Settings)
    bpy.types.ImageTexture.B2U_Texture_Settings = bpy.props.PointerProperty(type=B2U_Texture_Settings)
    
def unregister():

    # Base Unregister
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()